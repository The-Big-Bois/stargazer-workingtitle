# ~~ Globals ~~

orange = (255,100,0)
black = (0,0,0)
turqoise = (158,255,203)
green = (73,255,148)
red = (175,30,30)
gray = (128,128,128)
brown = (139,69,19)
start_pos = 360

# ~~ End Globals ~~